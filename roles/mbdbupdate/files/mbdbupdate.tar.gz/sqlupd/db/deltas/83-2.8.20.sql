SET NAMES 'utf8';

ALTER TABLE `usersblok` ADD INDEX `uid` (`uid`);
