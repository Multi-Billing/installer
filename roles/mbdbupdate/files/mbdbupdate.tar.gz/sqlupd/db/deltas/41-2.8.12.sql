SET NAMES 'utf8';

INSERT INTO `cabinet_config` (`parent` ,`key` ,`value`) VALUES ('system', 'user_registration_after_text', 'Ваш логин: %s\nВаш пароль: %s\nАдрес: http://isp.cabinet.net');
INSERT INTO `cabinet_config` (`parent` ,`key` ,`value`) VALUES ('system', 'user_registration_after_user', '1');
INSERT INTO `cabinet_config` (`parent` ,`key` ,`value`) VALUES ('system', 'user_registration_after_pass', '2');
INSERT INTO `cabinet_config` (`parent` ,`key` ,`value`) VALUES ('system', 'user_registration_after_uid', '0');
INSERT INTO `cabinet_config` (`parent` ,`key` ,`value`) VALUES ('gui', 'user_registration_after_on', '0');

