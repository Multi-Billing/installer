SET NAMES 'utf8';

INSERT INTO system_options (`key`, value) VALUES ('easysoft_link_with_dealer' , '0');
INSERT INTO system_options (`key`, value) VALUES ('easysoft_default_dealer' , '0');
 