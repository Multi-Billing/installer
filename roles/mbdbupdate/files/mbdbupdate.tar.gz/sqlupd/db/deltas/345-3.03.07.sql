--
-- Отключение внешних ключей 
--
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;

SET NAMES 'utf8';

ALTER TABLE `addons_swedbank` ADD `fio` VARCHAR(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_latvian_ci NULL DEFAULT NULL AFTER `account`;
ALTER TABLE `addons_swedbank` CHANGE `txn_id` `txn_id` VARCHAR(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_latvian_ci NULL DEFAULT NULL;
ALTER TABLE `addons_swedbank` CHANGE `account` `account` VARCHAR(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_latvian_ci NULL DEFAULT NULL;
ALTER TABLE `addons_swedbank` CHANGE `comment` `comment` VARCHAR(128) CHARACTER SET utf8mb4 COLLATE utf8mb4_latvian_ci NULL DEFAULT NULL;

--
-- Включение внешних ключей
--
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
