SET NAMES 'utf8';

INSERT INTO `system_options` (`key`, `value`) VALUES('auto_close_limit_by_deposit', '0');

