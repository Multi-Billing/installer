SET NAMES 'utf8';

INSERT INTO system_options (`key`, value) VALUES ('privat_pay_acc_oshadbank', '0');
INSERT INTO system_options (`key`, value) VALUES ('accel_unkn_session_timeout', '300');
INSERT INTO system_options (`key`, value) VALUES ('ciscoasr_unkn_sess_timeout', '300');
INSERT INTO system_options (`key`, value) VALUES ('ciscoasr_unkn_service', 'MBUNKNOWN');
INSERT INTO system_options (`key`, value) VALUES ('ciscoasr_blok_service', 'MBDISABLEDINET');
INSERT INTO system_options (`key`, value) VALUES ('ciscoasr_del_service', 'MBDELETED');
INSERT INTO system_options (`key`, value) VALUES ('ciscoasr_otkl_service', 'MBOTKL');
INSERT INTO system_options (`key`, value) VALUES ('ciscoasr_frez_service', 'MBFREEZE');
INSERT INTO system_options (`key`, value) VALUES ('ciscoasr_debt_service', 'MBNOMONEY');
INSERT INTO system_options (`key`, value) VALUES ('ciscoasr_inet_service', 'MBINTERNET');
