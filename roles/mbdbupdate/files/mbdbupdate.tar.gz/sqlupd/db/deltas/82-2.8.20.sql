SET NAMES 'utf8';

ALTER TABLE `usersdel` ADD INDEX `uid` (`uid`);
