SET NAMES 'utf8';


INSERT INTO system_options (`key`, value) VALUES ('mrtg_threads', '1');

